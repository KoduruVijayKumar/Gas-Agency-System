# Quick Commands Reference

## First Time Only (One-time setup)

Open Terminal in your project folder and run:

\`\`\`bash
git init
git add .
git commit -m "Initial GasFlow deployment"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/gasflow.git
git push -u origin main
\`\`\`

Replace `YOUR-USERNAME` with your GitHub username!

---

## Every Time You Make Changes

\`\`\`bash
git add .
git commit -m "Updated booking form"
git push origin main
\`\`\`

Then wait 1-2 minutes - Vercel auto-deploys!

---

## Check Deployment Status

1. Go to https://vercel.com/dashboard
2. Click your `gasflow` project
3. You'll see deployment status

---

## Your URLs

- GitHub: https://github.com/YOUR-USERNAME/gasflow
- Website: https://gasflow-YOUR-USERNAME.vercel.app
- Admin: https://gasflow-YOUR-USERNAME.vercel.app/dashboard/admin

---

## Test Credentials

**User Login:**
- Email: user@example.com
- Password: password123

**Admin Login:**
- Email: admin@gasflow.com
- Password: admin123

---

## Common Issues

| Problem | Solution |
|---------|----------|
| "git not found" | Install Git from https://git-scm.com |
| "Repository not found" | Check your username in the URL |
| "Permission denied" | Install GitHub Desktop or check SSH keys |
| Deployment takes 10min | Normal for first deployment, usually faster after |

That's it! You're good to go! 🎉
