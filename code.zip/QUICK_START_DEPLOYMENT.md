# Quick Start: 5 Minutes to Live Website

## Prerequisites
- GitHub account (free): https://github.com
- Vercel account (free): https://vercel.com

## 5-Minute Steps

### Step 1: Create GitHub Repo (2 min)
1. Go to https://github.com/new
2. Name it: `gasflow`
3. Set to Public
4. Click Create Repository
5. Copy the URL shown (e.g., https://github.com/yourname/gasflow.git)

### Step 2: Push Code to GitHub (2 min)
Open terminal in your project folder:
\`\`\`bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/gasflow.git
git push -u origin main
\`\`\`

Replace `YOUR-USERNAME` with your actual GitHub username!

### Step 3: Deploy on Vercel (1 min)
1. Go to https://vercel.com/new
2. Click "Import Git Repository"
3. Paste your GitHub URL or search for "gasflow"
4. Click Import
5. Click Deploy
6. Wait 2-3 minutes ⏳
7. Get your live URL! 🎉

## Your Live URL
After deployment, Vercel shows your URL:
\`\`\`
https://gasflow-yourname.vercel.app
\`\`\`

## Test It
Click the link and test:
- Landing page ✓
- User login ✓
- Admin login ✓
- Bookings ✓

## Make Changes Later
\`\`\`bash
# Edit files locally
# Then:
git add .
git commit -m "Updated feature"
git push origin main
# Vercel auto-deploys!
\`\`\`

That's it! Your website is live! 🚀

---

## Troubleshooting

**Command not found: git**
- Install from https://git-scm.com

**Permission denied**
- Use HTTPS URL instead of SSH

**Build failed**
- Check Vercel logs for errors
- Ensure package.json exists

---

Need help? Check GITHUB_DEPLOYMENT_GUIDE.md for detailed instructions.
